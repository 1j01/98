Sim City by Hankola

This is a game that I played when I was a younger version of myself on the cornerstone of all
video game systems the SNES. The melodies that came out of the television began in me the love
of video game music. My first attempt at ripping game music came from this game. All in all a
wonderful game with tons of replay value. Well worth the Wii points to download it if you haven't yet.

I would like to thank the now defunct Spriters Resource without whom I would have never been able to create
this here skin. 
I would also like to thank Luigi Hann for inspiration. This is not up to par with his work, but I did this for me and I had fun.

Sim City V1.2 -
This skin was made with MS Paint - again yuck! It was a labor of love really. Took a solid week for
the three main windows and their shades. The rest was added in another three of four days after I got
over my creative block. It was tough to make. Please do not reproduce and update and call your own. 

This skin focuses on the title screen theme of a neon type city although there is an equalizer to 
remind us all of the actual game. 

Version 1.2 fixes

-Video screen had a bug in top corner.(lines did not match up.)
-Whited some text for more coehesion with numbers ect.

Copyright 2008 Hankola Designs



